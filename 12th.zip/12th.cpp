#include <stdio.h>

int main() {
    int lulus = 0;
    int langkah = 1;

    while (!lulus) {
        printf("Langkah ke-%d agar lulus mata kuliah Algorithm and Programming:\n", langkah);

        if (langkah == 1) {
            printf("- Rajin ikut kelas\n");
        } else if (langkah == 2) {
            printf("- Kerjakan tugas tepat waktu\n");
        } else if (langkah == 3) {
            printf("- Belajar logika dan latihan ngoding\n");
        } else if (langkah == 4) {
            printf("- Tanya dosen atau teman kalau belum paham\n");
        } else {
            printf("- Tambah usaha lagi! (Langkah tambahan ke-%d)\n", langkah - 4);
        }

        printf("Sudah lulus? (1 = ya, 0 = belum): ");
        scanf("%d", &lulus);

        langkah++;
        printf("\n");
    }

    printf("Yeayy Kamu Lulus!!!!!!.\n");
    return 0;
}

