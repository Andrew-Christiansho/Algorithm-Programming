#include <stdio.h>

int main(){
	float assignment;
	float mid;
	float final;
	float FinalScore;
	
	printf("Masukkan Nilai Assignment:");
	scanf("%f", &assignment);
	
	printf("Masukkan Nilai Mid Exam:");
	scanf("%f", &mid);
	
	printf("Masukkan Nilai Final Exam:");
	scanf("%f", &final);
	
	FinalScore = 0.2 * assignment + 0.3 * mid + 0.5 * final;
	
	printf("Final Score: %.2f\n", FinalScore);
	
	return 0;
}
