#include <stdio.h>

int main(){
	int pilihan;
	
	printf("===== STREAMING ======\n");
	
	printf("1.Software Engineering\n");
	printf("2.Intelligence System\n");
	printf("3.Network Technology\n");
	printf("4.Database Technology\n");
	printf("5.Interactive Multimedia\n");
	
	
	printf("Masukkan Pilihan Anda: ");
	scanf("%d", &pilihan);
	
	if (pilihan==1){
		printf("Streaming yang anda pilih: Software Engineering");
	} else if (pilihan == 2){
		printf("Streaming yang anda pilih: Intelligence System");
	} else if (pilihan == 3){
		printf("Streaming yang anda pilih: Network Technology");
	} else if (pilihan  == 4){
		printf("Streaming yang anda pilih: Database Technology");
	} else if (pilihan == 5){
		printf("Streaming yang anda pilih: Interactive Multimedia");
	} else{
		printf("Pilihan Tidak Valid");
	}
	return 0;
}
